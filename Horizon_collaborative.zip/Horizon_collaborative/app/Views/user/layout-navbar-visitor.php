        <nav>
          <div class="logo">
            <a href="/"><img src="/Horizon/Assets/img/logo.png" width="200px" alt="" /></a>
          </div>
          <ul>
          <li>
              <a href="/tour">Paket Tour</a>
            </li>
            <li>
              <a href="/trekking">Paket Trekking</a>
            </li>
            <li>
              <a href="/login"><div class="loginfront">Login</div></a>
            </li>
          </ul>
        </nav>