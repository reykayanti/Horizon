        <nav>
          <div class="logo">
            <a href="/"><img src="/Horizon/Assets/img/logo.png" width="200px" alt="" /></a>
          </div>
          <ul>
          <li>
              <a href="/tour">Paket Tour</a>
            </li>
            <li>
              <a href="/trekking">Paket Trekking</a>
            </li>
            <li>
            <abbr title="Cart">
              <a href="/cart">
                <img src="/Horizon/Assets/icon/shopping-cart.png" width="20px" alt="" />
              </a>
              </abbr>
            </li>
            <li>
            <abbr title="History">
              <a href="/history">
                <img src="/Horizon/Assets/icon/history.png" width="20px" alt="" />
              </a>
              </abbr>
            </li>
            <li>
              <div class="drop" style="color: white;">
                <img src="/Horizon/Assets/icon/user.png" width="20px" alt="" />
                <div class="dropdown">
                  <div class="a">
                    <a href="/profile"> Profile </a>
                  </div>
                  <div class="a">
                    <a href="/logout"> Logout</a>
                  </div>
                </div>
              </div>
            </li>
          </ul>
        </nav>